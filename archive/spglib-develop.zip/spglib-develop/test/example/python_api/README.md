# Python example

This is an example of how to use Spglib through the Python api

Assuming you have installed spglib using pip or anaconda, you can simply `import spglib` and access the internal apis.

## Running the example

```console
$ python example.py
```
