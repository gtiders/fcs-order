// Copyright (C) 2016 Atsushi Togo
// This file is part of spglib.
// SPDX-License-Identifier: BSD-3-Clause

#ifndef __arithmetic_H__
#define __arithmetic_H__

int arth_get_symbol(char symbol[7], int const spgroup_number);

#endif
