# Developer document

```{toctree}
---
maxdepth: 1
---
   Performance <performance>
   Flags to control action of magnetic symmetry operations <magnetic_symmetry_flags>
```
