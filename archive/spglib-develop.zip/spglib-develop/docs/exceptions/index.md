# Exceptions

Depending on the API language used, Spglib will try to throw a structured
exception based on the language support for exceptions. See the links below
for more details on the exception types used.

```{toctree}
---
maxdepth: 1
---
python
```

```{note}
Currently only the python API supports exceptions.
```
