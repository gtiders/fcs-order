# Python API exceptions

```{eval-rst}
.. automodule:: spglib.error
   :members:
   :no-index:
```
