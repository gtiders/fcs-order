# API Reference

```{toctree}
---
caption: Python API
glob:
maxdepth: 1
---
autodoc/*
```
