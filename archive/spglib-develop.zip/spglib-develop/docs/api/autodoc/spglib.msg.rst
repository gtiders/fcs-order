spglib.msg module
=================

.. automodule:: spglib.msg
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
