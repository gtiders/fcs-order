spglib.utils module
===================

.. automodule:: spglib.utils
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
