spglib.error module
===================

.. automodule:: spglib.error
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
