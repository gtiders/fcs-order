spglib.kpoints module
=====================

.. automodule:: spglib.kpoints
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
