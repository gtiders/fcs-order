spglib.\_internal module
========================

.. automodule:: spglib._internal
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
