spglib.spg module
=================

.. automodule:: spglib.spg
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
