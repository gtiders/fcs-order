spglib package
==============

.. automodule:: spglib
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 4

   spglib._internal
   spglib.cell
   spglib.error
   spglib.kpoints
   spglib.msg
   spglib.reduce
   spglib.spg
   spglib.utils
