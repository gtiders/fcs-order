#!/bin/sh

~/anaconda/bin/python2.7 setup.py build --build-lib=. --build-platlib=.
